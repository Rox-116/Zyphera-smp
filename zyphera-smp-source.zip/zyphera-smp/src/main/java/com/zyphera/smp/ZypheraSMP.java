package com.zyphera.smp;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class ZypheraSMP extends JavaPlugin {

    private WelcomeHologramListener listener;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.listener = new WelcomeHologramListener(this);
        getServer().getPluginManager().registerEvents(listener, this);
        getLogger().info("ZypheraSMP aktif edildi. LuckPerms bulundu: " + listener.isLuckPermsHooked());
    }

    @Override
    public void onDisable() {
        if (listener != null) {
            listener.removeAllHolograms();
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("zyphera.admin")) {
            sender.sendMessage("§cBu komutu kullanma yetkin yok.");
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            listener.reload();
            sender.sendMessage("§dZypheraSMP §7ayarlari yeniden yuklendi.");
            return true;
        }
        sender.sendMessage("§d/zyphera reload §7- config.yml dosyasini yeniden yukler");
        return true;
    }
}
