package com.zyphera.smp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Spawns a purple "ZYPHERA SMP" welcome hologram that only the joining
 * player can see, positioned a few blocks in front of them. It refreshes
 * the online count / ping every second and removes itself after a
 * configurable amount of time or when the player disconnects.
 */
public class WelcomeHologramListener implements Listener {

    private final ZypheraSMP plugin;
    private final Map<UUID, HologramInstance> active = new ConcurrentHashMap<>();
    private LuckPerms luckPerms;

    public WelcomeHologramListener(ZypheraSMP plugin) {
        this.plugin = plugin;
        hookLuckPerms();
    }

    private void hookLuckPerms() {
        try {
            this.luckPerms = LuckPermsProvider.get();
        } catch (Throwable t) {
            this.luckPerms = null;
        }
    }

    public boolean isLuckPermsHooked() {
        return luckPerms != null;
    }

    public void reload() {
        hookLuckPerms();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        // Slight delay so the player's client has finished loading chunks.
        Bukkit.getScheduler().runTaskLater(plugin, () -> spawnHologram(player), 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        removeHologram(event.getPlayer().getUniqueId());
    }

    private void spawnHologram(Player player) {
        if (!player.isOnline()) return;

        removeHologram(player.getUniqueId());

        double forward = plugin.getConfig().getDouble("offset.forward", 3.0);
        double up = plugin.getConfig().getDouble("offset.up", 1.5);

        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection().setY(0).normalize();
        Location spawnLoc = player.getLocation().clone().add(dir.multiply(forward));
        spawnLoc.setY(player.getLocation().getY() + up);
        spawnLoc.setPitch(0);
        spawnLoc.setYaw(0);

        TextDisplay display = player.getWorld().spawn(spawnLoc, TextDisplay.class, td -> {
            td.setBillboard(Display.Billboard.CENTER);
            td.setSeeThrough(false);
            td.setShadowed(true);
            td.setDefaultBackground(true);
            td.setPersistent(false);
            td.setVisibleByDefault(false);
        });

        player.showEntity(plugin, display);

        int seconds = plugin.getConfig().getInt("display-seconds", 20);

        BukkitTask task = new BukkitRunnable() {
            int ticksLeft = seconds * 20;

            @Override
            public void run() {
                if (!player.isOnline() || display.isDead() || ticksLeft <= 0) {
                    removeHologram(player.getUniqueId());
                    return;
                }
                display.text(buildText(player));
                ticksLeft -= 20;
            }
        }.runTaskTimer(plugin, 0L, 20L);

        active.put(player.getUniqueId(), new HologramInstance(display, task));
    }

    private void removeHologram(UUID uuid) {
        HologramInstance instance = active.remove(uuid);
        if (instance != null) {
            instance.task.cancel();
            if (!instance.display.isDead()) {
                instance.display.remove();
            }
        }
    }

    public void removeAllHolograms() {
        for (UUID uuid : List.copyOf(active.keySet())) {
            removeHologram(uuid);
        }
    }

    private Component buildText(Player player) {
        String rank = resolveRank(player);
        int online = Bukkit.getOnlinePlayers().size();
        int max = Bukkit.getMaxPlayers();
        int ping = player.getPing();
        String world = player.getWorld().getName();
        String domain = plugin.getConfig().getString("server-domain", "zyphera.skymc.io");

        StringBuilder sb = new StringBuilder();
        sb.append(plugin.getConfig().getString("title", "&5&lZYPHERA SMP")).append('\n');
        for (String line : plugin.getConfig().getStringList("lines")) {
            sb.append(format(line, player.getName(), world, rank, online, max, ping, domain)).append('\n');
        }
        sb.append(format(plugin.getConfig().getString("footer", ""), player.getName(), world, rank, online, max, ping, domain));

        return LegacyComponentSerializer.legacyAmpersand().deserialize(sb.toString());
    }

    private String format(String raw, String playerName, String world, String rank, int online, int max, int ping, String domain) {
        if (raw == null) return "";
        return raw
                .replace("{player}", playerName)
                .replace("{world}", world)
                .replace("{rank}", rank)
                .replace("{online}", String.valueOf(online))
                .replace("{max}", String.valueOf(max))
                .replace("{ping}", String.valueOf(ping))
                .replace("{domain}", domain);
    }

    private String resolveRank(Player player) {
        if (luckPerms != null) {
            try {
                User user = luckPerms.getUserManager().getUser(player.getUniqueId());
                if (user != null) {
                    String group = user.getPrimaryGroup();
                    if (group != null && !group.isBlank()) {
                        return capitalize(group);
                    }
                }
            } catch (Throwable ignored) {
                // fall through to default
            }
        }
        return plugin.getConfig().getString("default-rank", "Uye");
    }

    private String capitalize(String s) {
        if (s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private record HologramInstance(TextDisplay display, BukkitTask task) {
    }
}
